package sudhakar.springmvcuser.studentmanagement.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import sudhakar.springmvcuser.studentmanagement.entity.Student;

public interface StudentRepository extends JpaRepository<Student, Integer> {

}
