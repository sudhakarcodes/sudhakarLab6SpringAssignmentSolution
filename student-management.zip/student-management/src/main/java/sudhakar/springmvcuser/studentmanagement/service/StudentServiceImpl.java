package sudhakar.springmvcuser.studentmanagement.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import sudhakar.springmvcuser.studentmanagement.entity.Student;
import sudhakar.springmvcuser.studentmanagement.repository.StudentRepository;

@Service

public class StudentServiceImpl implements StudentService {

	@Autowired
	private StudentRepository studentrepository;
	
	@Override
	public List<Student> findAll() {
		// TODO Auto-generated method stub
		return studentrepository.findAll();
	}

	@Override
	public Student findById(int id) {
		// TODO Auto-generated method stub
		return studentrepository.findById(id).get();
	}

	@Override
	public void save(Student student) {
		// TODO Auto-generated method stub
		studentrepository.save(student);
	}

	@Override
	public void deleteById(int id) {
		// TODO Auto-generated method stub
		studentrepository.deleteById(id);
	}

}
