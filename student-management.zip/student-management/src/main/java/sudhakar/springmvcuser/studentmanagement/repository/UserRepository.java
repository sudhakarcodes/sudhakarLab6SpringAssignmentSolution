package sudhakar.springmvcuser.studentmanagement.repository;


import org.springframework.data.jpa.repository.JpaRepository;

import sudhakar.springmvcuser.studentmanagement.entity.User;

public interface UserRepository extends JpaRepository<User,Integer> {
	public User findByUsername(String username);
}
